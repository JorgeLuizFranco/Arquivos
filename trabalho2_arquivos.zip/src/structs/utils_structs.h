#ifndef UTILS_STRUCTS_H
#define UTILS_STRUCTS_H

// comentado no .c

int compara_string_limitada(char* s1, char* s2, int tamanho, int flag_s2_dinamica);
void copia_array_char(char* dest, char* src, int tamanho);
void troca(void** var1, void** var2);

#endif
